#ifndef _GEORGE_H_
#define _GEORGE_H_

#include "george/exceptions.h"
#include "george/kernels.h"
#include "george/hodlr.h"

#endif
