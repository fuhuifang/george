George is being developed by `Dan Foreman-Mackey (@dfm)
<https://github.com/dfm>`_ with many contributions from:

- `Ruth Angus (@RuthAngus) <https://github.com/RuthAngus>`_
- `Jonah Bernhard (@jbernhard) <https://github.com/jbernhard>`_
- `Miguel de Val-Borro (@migueldvb) <https://github.com/migueldvb>`_
- `Gregory Hitz (@hitzg) <https://github.com/hitzg>`_
- `Stephan Hoyer (@shoyer) <https://github.com/shoyer>`_
- `Simon Walker (@mindriot101) <https://github.com/mindriot101>`_
